UpdateTheme est une cr�ation de Nordic Power. 
Ce script permet de t�l�charger des themes sur internet � travers une plateforme personnalis�e

Les sources sont disponibles � l'adresse suivante : https://github.com/nordicpower/recalbox-script-tools